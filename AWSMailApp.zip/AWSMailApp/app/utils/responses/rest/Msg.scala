package utils.responses.rest

import play.api.libs.json._
import play.api.libs.functional.syntax._
import play.api.i18n.Messages

sealed class Msg protected (val message: String, val data: Option[JsValue], val token: Option[String], val status: MsgStatus)
class MsgOK(message: String, data: Option[JsValue], token: Option[String]) extends Msg(message, data, token, MsgStatusOK())
class MsgERR(message: String, data: Option[JsValue], token: Option[String]) extends Msg(message, data, token, MsgStatusError())

object Msg {
  implicit val msgWrites = new Writes[Msg] {
    override def writes(m: Msg): JsValue = {
      Json.obj(
          "message" -> m.message,
          "status" -> m.status,
          "data" -> m.data,
          "token" -> m.token
      )
    }
  }

}

object MsgOK {
  def apply(message: String, data: JsValue): MsgOK = new MsgOK(message, Some(data), None)
  def apply(message: String, token: String): MsgOK = new MsgOK(message, None, Some(token))
  def apply(message: String, data: JsValue, token: String): MsgOK = new MsgOK(message, Some(data), Some(token))
  def apply(message: String): MsgOK = new MsgOK(message, None, None)
}

object MsgERR {
  def apply(message: String, data: JsValue): MsgERR = new MsgERR(message, Some(data), None)
  def apply(message: String, token: String): MsgERR = new MsgERR(message, None, Some(token))
  def apply(message: String, data: JsValue, token: String): MsgERR = new MsgERR(message, Some(data), Some(token))
  def apply(message: String): MsgERR = new MsgERR(message, None, None)
}