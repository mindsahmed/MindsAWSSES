package models.users

import play.api.libs.json.Writes
import play.api.libs.json.JsValue
import play.api.libs.json._
import play.api.libs.functional.syntax._
import anorm._
import anorm.SqlParser._
import play.api.db._
import play.api.Play.current

case class Owner (
  ownerId: Long,
  name: String,
  password: String,
  emailId: String,
  address: String,
  contact: String
  
)

object Owner {
  
  implicit val ownerWrites = new Writes[Owner] {
    def writes(ul: Owner): JsValue = Json.obj(
      "ownerId" -> ul.ownerId,
      "name" -> ul.name,
      "password" -> ul.password,
      "emailId" -> ul.emailId,
      "address" -> ul.address,
      "contact" -> ul.contact)
  }
  
   implicit val reads: Reads[Owner] = (
    (__ \ "ownerId").read[Long] ~
    (__ \ "name").read[String] ~
    (__ \ "password").read[String] ~
    (__ \ "emailId").read[String] ~
    (__ \ "address").read[String] ~
    (__ \ "contact").read[String])(Owner.apply(_, _, _, _, _, _))


    val OwnerSimple = {
    get[Int]("ownerId") ~ 
    get[String]("name") ~
    get[String]("password") ~
    get[String]("emailId") ~
    get[String]("address") ~
    get[String]("contact") map {
      case(id ~ nm ~ pwd ~ email ~ adrs ~ cont ) => Owner(ownerId = id, name = nm,
        password = pwd, emailId = email, address = adrs, contact = cont)
      }
    }


    def checkForCredencials(emailId: String,password: String): Option[Owner] = {
      DB.withConnection { implicit conn =>
      println(" emailId : "+emailId+" password : "+password)
      val owner = (SQL("""
        SELECT
          *
        FROM
          `owner` `own`
        WHERE
          `own`.`emailId` = {emailId}
          AND `own`.`password` = {password}
      """).on('emailId -> emailId,'password -> password).as(OwnerSimple singleOpt))
      println(" checkForCredencials Finished")
      owner
      }
    }

    def checkForEmailId(emailId: String): Option[Owner] = {
      DB.withConnection { implicit conn =>
      println(" emailId : "+emailId)
      val owner = (SQL("""
        SELECT
          *
        FROM
          `owner` `own`
        WHERE
          `own`.`emailId` = {emailId}
      """).on('emailId -> emailId).as(OwnerSimple singleOpt))
      println(" checkForEmailId Finished")
      owner
      }
    }

    def save(owner: Owner): Owner = {
      val ownerId:Long = DB.withConnection { implicit conn =>
        println(" insert owner started")
         val ownerId = SQL("""
      INSERT INTO `owner` 
        (`name`,`password`,`emailId`,`address`,`contact`)
      VALUES
        ({name},{password},{emailId},{address},{contact})
      """) on (
        'name -> owner.name,
        'password -> owner.password,
        'emailId -> owner.emailId,
        'address -> owner.address,
        'contact -> owner.contact) executeInsert (scalar[Long] single)
      ownerId       
     }
    DB.withConnection { implicit conn =>
      println(" insert owner center")
      val own = (SQL("""
        SELECT
          `own`.`ownerId`,
          `own`.`name`,
          `own`.`password`,
          `own`.`emailId`,
          `own`.`address`,
          `own`.`contact`
        FROM
          `owner` `own`
        WHERE
          `own`.`ownerId` = {ownerId}
      """).on('ownerId -> ownerId).as(OwnerSimple singleOpt)).get
      println(" insert owner finished")
      own
    }
    }
}