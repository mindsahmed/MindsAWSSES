package models.users

import play.api.libs.json.Writes
import play.api.libs.json.JsValue
import play.api.libs.json._
import play.api.libs.functional.syntax._
import anorm._
import anorm.SqlParser._
import play.api.db._
import play.api.Play.current

//import javax.inject.Inject

case class Message(
  messageId: Long,
  messageTo: String,
  subject: String,
  matter: String,
  ownerId: Long
	)

object Message {


  implicit val MessageWrites = new Writes[Message] {
    def writes(ul: Message): JsValue = Json.obj(
      "messageId" -> ul.messageId,
      "messageTo" -> ul.messageTo,
      "subject" -> ul.subject,
      "matter" -> ul.matter,
      "ownerId" -> ul.ownerId)
  }
  
   implicit val reads: Reads[Message] = (
    (__ \ "messageId").read[Long] ~
    (__ \ "messageTo").read[String] ~
    (__ \ "subject").read[String] ~
    (__ \ "matter").read[String] ~
    (__ \ "ownerId").read[Long])(Message.apply(_, _, _, _, _))

  val MessageSimple = {
    get[Long]("messageId") ~ 
    get[String]("messageTo") ~
    get[String]("messageTopic") ~
    get[String]("messageMatter") ~
    get[Long]("messageByOwnerId") map {
      case (id ~ mTo ~ sub ~ mat ~ oId) => Message(messageId = id, messageTo = mTo,
        subject = sub, matter = mat,ownerId = oId) 
    }
  }

  def allMessageByOwnerId(ownerId: Long): List[Message] = DB.withConnection { implicit c =>
  SQL("select * from Message where messageByOwnerId = {messageByOwnerId}").on('messageByOwnerId -> ownerId).as(MessageSimple *)
  }
  
  def saveMessage(message: Message): Message = {
      val messageId:Long = DB.withConnection { implicit conn =>
        println(" insert Message started")
         val messageId = SQL("""
      INSERT INTO `message` 
        (`messageTo`,`messageTopic`,`messageMatter`,`messageByOwnerId`)
      VALUES
        ({messageTo},{messageTopic},{messageMatter},{messageByOwnerId})
      """) on (
        'messageTo -> message.messageTo,
        'messageTopic -> message.subject,
        'messageMatter -> message.matter,
        'messageByOwnerId -> message.ownerId) executeInsert (scalar[Long] single)
      messageId       
     }
    DB.withConnection { implicit conn =>
      println(" insert Message center")
      val clnt = (SQL("""
        SELECT
          `own`.`messageId`,
          `own`.`messageTo`,
          `own`.`messageTopic`,
          `own`.`messageMatter`,
          `own`.`messageByOwnerId`
        FROM
          `Message` `own`
        WHERE
          `own`.`messageId` = {messageId}
      """).on('messageId -> messageId).as(MessageSimple singleOpt)).get
      println(" insert Message finished")
      clnt
    }
  } 
}