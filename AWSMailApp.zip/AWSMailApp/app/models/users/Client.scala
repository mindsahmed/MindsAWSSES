package models.users

import play.api.libs.json.Writes
import play.api.libs.json.JsValue
import play.api.libs.json._
import play.api.libs.functional.syntax._
import anorm._
import anorm.SqlParser._
import play.api.db._
import play.api.Play.current

//import javax.inject.Inject

case class Client(
	clinetId: Long, 
	clientFirstName: String,
  clientLastName: String,
  clientEmail: String,
  ownerId: Long
	)

object Client {


  implicit val clientWrites = new Writes[Client] {
    def writes(ul: Client): JsValue = Json.obj(
      "clinetId" -> ul.clinetId,
      "clientFirstName" -> ul.clientFirstName,
      "clientLastName" -> ul.clientLastName,
      "clientEmail" -> ul.clientEmail,
      "ownerId" -> ul.ownerId)
  }
  
   implicit val reads: Reads[Client] = (
    (__ \ "clinetId").read[Long] ~
    (__ \ "clientFirstName").read[String] ~
    (__ \ "clientLastName").read[String] ~
    (__ \ "clientEmail").read[String] ~
    (__ \ "ownerId").read[Long])(Client.apply(_, _, _, _, _))

  val ClientSimple = {
    get[Long]("clientId") ~ 
    get[String]("firstName") ~
    get[String]("lastName") ~
    get[String]("clinetEmailId") ~
    get[Long]("ownerId") map {
      case (id ~ fNm ~ lNm ~ cEmail ~ oId) => Client(clinetId = id,clientFirstName = fNm, 
        clientLastName = lNm, clientEmail = cEmail,ownerId = oId) 
    }
  }

  def allClinetsByOwnerId(ownerId: Long): List[Client] = DB.withConnection { implicit c =>
  SQL("select * from Client where ownerId = {ownerId}").on('ownerId -> ownerId).as(ClientSimple *)
  }

  def checkForEmailId(clientEmail: String): Option[Client] = {
    DB.withConnection { implicit conn =>
      println(" Client emailId : "+clientEmail)
      val client = (SQL("""
        SELECT
          *
        FROM
          `Client` `own`
        WHERE
          `own`.`clinetEmailId` = {clinetEmailId}
      """).on('clinetEmailId -> clientEmail).as(ClientSimple singleOpt))
      println(" checkForEmailId Client Finished")
      client
      }
  }
  
  def saveClient(client: Client): Client = {
      val clientId:Long = DB.withConnection { implicit conn =>
        println(" insert Client started")
         val clientId = SQL("""
      INSERT INTO `client` 
        (`firstName`,`lastName`,`clinetEmailId`,`ownerId`)
      VALUES
        ({firstName},{lastName},{clinetEmailId},{ownerId})
      """) on (
        'firstName -> client.clientFirstName,
        'lastName -> client.clientLastName,
        'clinetEmailId -> client.clientEmail,
        'ownerId -> client.ownerId) executeInsert (scalar[Long] single)
      clientId       
     }
    DB.withConnection { implicit conn =>
      println(" insert Client center")
      val clnt = (SQL("""
        SELECT
          `own`.`clientId`,
          `own`.`firstName`,
          `own`.`lastName`,
          `own`.`clinetEmailId`,
          `own`.`ownerId`
        FROM
          `client` `own`
        WHERE
          `own`.`clientId` = {clientId}
      """).on('clientId -> clientId).as(ClientSimple singleOpt)).get
      println(" insert Client finished")
      clnt
    }
  }

/*def delete(id: Long) {
    DB.withConnection { implicit c =>
      SQL("delete from Client where id = {id}").on(
        'id -> id
      ).executeUpdate()
    }
  }*/
  
}