package models.security
import play.api.libs.json.Writes
import play.api.libs.json.JsValue
import play.api.libs.json._
import play.api.libs.functional.syntax._




case class ClientSignUp (
  clientFirstName: String,
  clientLastName: String,
  clientEmail: String,
  ownerId: Long
 )
 
object ClientSignUp {
  implicit val reads: Reads[ClientSignUp] = (
  	(JsPath \ "clientFirstName").read[String] ~
  	(JsPath \ "clientLastName").read[String] ~
    (JsPath \ "clientEmail").read[String] ~
    (JsPath \ "ownerId").read[Long])(ClientSignUp.apply(_, _, _, _))

}