package models.security
import play.api.libs.json.Writes
import play.api.libs.json.JsValue
import play.api.libs.json._
import play.api.libs.functional.syntax._




case class SignUp (
  name: String,
  password: String,
  emailId: String,
  address: String,
  contact: String
 )
 
object SignUp {
  implicit val reads: Reads[SignUp] = (
  	(JsPath \ "name").read[String] ~
  	(JsPath \ "password").read[String] ~
    (JsPath \ "emailId").read[String] ~
    (JsPath \ "address").read[String] ~
    (JsPath \ "contact").read[String] )(SignUp.apply(_, _, _, _, _))

}