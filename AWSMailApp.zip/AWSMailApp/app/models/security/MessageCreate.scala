package models.security
import play.api.libs.json.Writes
import play.api.libs.json.JsValue
import play.api.libs.json._
import play.api.libs.functional.syntax._




case class MessageCreate (
  messageTo: String,
  subject: String,
  matter: String,
  ownerId: Long
 )
 
object MessageCreate {
  implicit val reads: Reads[MessageCreate] = (
  	(JsPath \ "messageTo").read[String] ~
    (JsPath \ "subject").read[String] ~
    (JsPath \ "matter").read[String] ~
    (JsPath \ "ownerId").read[Long])(MessageCreate.apply(_, _, _, _))

}