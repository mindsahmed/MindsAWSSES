package models.security
import play.api.libs.json.Writes
import play.api.libs.json.JsValue
import play.api.libs.json._
import play.api.libs.functional.syntax._




case class Login (
  emailId: String,
  password: String
 )
 
object Login {
  implicit val reads: Reads[Login] = (
    (JsPath \ "emailId").read[String] ~
    (JsPath \ "password").read[String])(Login.apply(_, _))

}