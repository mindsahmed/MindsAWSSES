package controllers

import play.api._
import play.api.mvc._
import models.security.Login
import models.security.SignUp
import models.security.MessageCreate
import models.security.ClientSignUp
import models.users.Owner
import models.users.Message
import models.users.Client
import scala.concurrent.Future
import play.api.Play.current
import play.api.mvc.Result
import play.api.libs.concurrent.Execution.Implicits._
import play.api.libs.json._
import utils.responses.rest.MsgOK
import utils.responses.rest.MsgERR
import play.api.libs.json.Json.toJson
import play.api.libs.json.JsError
/*import models.Task
import play.api.data._
import play.api.data.Forms._*/


object Application extends Controller {

  def index = Action {
    Ok(views.html.index())
  	//Redirect(routes.Application.tasks)
  }

  def signIn = Action.async(parse.json) { implicit request =>
     println(" Term Create ")
     request.body.validate[Login] match {
        case JsSuccess(login, _) =>
              var flag: Boolean = false
              var owner = Owner.checkForCredencials(login.emailId,login.password)
              owner match {
                case Some(owner) => flag = true
                case _ => flag = false
              }
              if(flag)
              Future.successful(Ok(toJson(MsgOK("Login is successful",Json.obj("owner" -> owner)))))
              else
              Future.successful(Ok(toJson(MsgERR("Email Id (or) Password Incorrect"))))
              case JsError(e) => Future.successful(Ok(toJson(MsgERR("Error", JsError.toFlatJson(e)))))
     }
 }

   def signUp = Action.async(parse.json) { implicit request =>
    request.body.validate[SignUp] match {
      case JsSuccess(signUp, _) =>
        var ownerEmail = Owner.checkForEmailId(signUp.emailId)
        ownerEmail match {
          case Some(ownerEmail) => /* user already exists! */
            Future.successful(Conflict(toJson(MsgERR("Email Id already exists...!"))))
          case _ => var owner = Owner(ownerId = 0,name = signUp.name,password = signUp.password,emailId = signUp.emailId,address = signUp.address,
                              contact = signUp.contact)
                    owner = Owner.save(owner)
                    /*val response = Ok(toJson(MsgOK("You have been signed up succesfully.", Json.obj(
                "session" -> Token(token = authenticator.id, expiresOn = authenticator.expirationDate),"owner" -> owner))))*/
                    Future.successful(Ok(toJson(MsgOK("Owner SignUp Has Been Done Succesfully.",Json.obj("owner" -> owner)))))
        }
      case JsError(e) => Future.successful(Conflict(toJson(MsgERR("Error", JsError.toFlatJson(e)))))
      }
    }

    def createClient = Action.async(parse.json) { implicit request =>
    request.body.validate[ClientSignUp] match {
      case JsSuccess(clientSignUp, _) =>
        var clientEmail = Client.checkForEmailId(clientSignUp.clientEmail)
        clientEmail match {
          case Some(clientEmail) => /* user already exists! */
            Future.successful(Conflict(toJson(MsgERR("Client Email Id already exists...!"))))
          case _ => var client = Client(clinetId = 0,clientFirstName = clientSignUp.clientFirstName,clientLastName = clientSignUp.clientLastName,
                                clientEmail = clientSignUp.clientEmail, ownerId  = clientSignUp.ownerId)
                    client = Client.saveClient(client)
                    Future.successful(Ok(toJson(MsgOK("Client SignUp Has Been Done Succesfully.",Json.obj("client" -> client)))))
        }
      case JsError(e) => Future.successful(Conflict(toJson(MsgERR("Error", JsError.toFlatJson(e)))))
      }
    }

    def getAllClientsByOwnerId(ownerId: Long) = Action.async { implicit request => 
        val clientList = Client.allClinetsByOwnerId(ownerId)
        Future(Ok(toJson(clientList)))
    }


    def createMessage = Action.async(parse.json) { implicit request =>
    request.body.validate[MessageCreate] match {
      case JsSuccess(messageCreate, _) =>
           var messageToList: Array[String] = messageCreate.messageTo.split(",")
           for(msgTo <- messageToList){
              var message = Message(messageId = 0,messageTo = msgTo,subject = messageCreate.subject,
              matter = messageCreate.matter,ownerId = messageCreate.ownerId)
              message = Message.saveMessage(message)
           }
           Future.successful(Ok(toJson(MsgOK("All Message's Has Been Sent Succesfully."/*,Json.obj("message" -> message)*/))))
      case JsError(e) => Future.successful(Conflict(toJson(MsgERR("Error", JsError.toFlatJson(e)))))
      }
    }

    def allMessageByOwnerId(ownerId: Long) = Action.async { implicit request => 
        val messageList = Message.allMessageByOwnerId(ownerId)
        Future(Ok(toJson(messageList)))
    }
}