'use strict';

/* Controllers */

var appControllers = angular.module('appControllers', []);

appControllers.controller('AppCtrl', [ '$scope', '$location', 'USER_ROLES', 'Auth',
		function($scope, $location, USER_ROLES, Auth) {

			$scope.currentUser = null;
			$scope.userRoles = USER_ROLES;
			$scope.isAuthorized = Auth.isAuthorized;
			$scope.isAuthenticated = Auth.isAuthenticated;

			$scope.setCurrentUser = function(user) {
				$scope.currentUser = user;
			};

			$scope.isActiveLocation = function(viewLocation) {
				return viewLocation === $location.path();
			};
		} ]);

appControllers.controller('MessageListCtrl', [ '$routeParams',  '$scope', 'User', '$localStorage', 'Message', 'Auth', 'UIMessage',
		function($routeParams, $scope, User, $localStorage, Message, Auth, UIMessage) {
			
			
			
			$scope.ownerId=$localStorage.owner.Id
			$scope.messages = Message.query({ownerId : $scope.ownerId});
			$scope.users = User.query({ownerId : $scope.ownerId });
			$scope.showNewMessage = false;
			$scope.Message = {
				messageTo: $scope.users.clinetId,
	  			subject: '',
	 			matter: '',
	  			ownerId: parseInt($scope.ownerId)
			}

			$scope.sendMessage = function() {
				// Message.save
				Auth.createMessage($scope.Message, function(response) {
					$scope.showNewMessage = false;
					UIMessage.success(response.message);
					console.log("success message from backend to controller"+ message);
					$scope.messages.unshift(response.data.item);
					$location.path('/messages');
				}, function(response) {
					UIMessage.error(response.statusText)
				});
			};

			$scope.removeMessage = function(id) {
				Message.remove({
					messageId: id
				}, function(response) {
					UIMessage.success(response.message);

					angular.forEach($scope.messages, function(msg, i) {
						if (msg.id === id)
							$scope.messages.splice(i, 1);
					});
				}, function(response) {
					UIMessage.error(response.statusText)
				});
			};

			$scope.markRead = function(id) {
				Message.markRead({
					id: id
				}, function(response) {

					angular.forEach($scope.messages, function(msg, i) {
						if (msg.id === id)
							$scope.messages[i].isRead = true;
					});
				}, function(response) {
					UIMessage.error(response.statusText)
				});
			};
		} ]);

appControllers.controller('UserListCtrl', [ '$scope', '$routeParams', 'User', 'Auth', 'UIMessage',
		function($scope, $routeParams, User, Auth, UIMessage) {
			
			$scope.ownerId = $routeParams.id;
			$scope.users = User.query({ownerId : $scope.ownerId });
			$scope.user = {
				clientFirstName: '',
  				clientLastName: '',
  				clientEmail: '',
  				ownerId: parseInt($routeParams.id)
			};
			
			$scope.dialog = {
				showNewEdit: false,
				show: 'new',
				hideNewEdit: function() {
					$scope.dialog.showNewEdit = false;
				},
				showNewDialog: function() {
					$scope.user = {
						clientFirstName: '',
  						clientLastName: '',
  						clientEmail: '',
  						ownerId: parseInt($routeParams.id)
					};
					$scope.dialog.showNewEdit = true;
					$scope.dialog.show = 'new';
				},
				showEditDialog: function(user) {
					$scope.user = angular.copy(user);
					$scope.dialog.showNewEdit = true;
					$scope.dialog.show = 'edit';
				},
				dialogAction: function() {
					if ($scope.dialog.show == 'new')
						$scope.createUser()
					else
						$scope.updateUser()
				}
			};

			$scope.createUser = function() {
				Auth.create($scope.user, function(response) {
					$scope.dialog.hideNewEdit();
					UIMessage.success(response.message);
					$scope.users.unshift(response.item);
				}, function(response) {
					UIMessage.error(response.statusText)
				})
			};
			
		} ]);

appControllers.controller('LoginCtrl', [ '$scope', '$rootScope','$localStorage', '$location', 'AUTH_EVENTS',
		'Auth', 'UIMessage', function($scope, $rootScope, $localStorage, $location, AUTH_EVENTS, Auth, UIMessage) {
			$scope.credentials = {
				emailId: 'User1@gmail.com',
  				password: '123'
			};

			$scope.isProcessing = false;
			$scope.isReady = false;

			$scope.isDisabled = function() {
				return $scope.isProcessing || $scope.isReady;
			};

			$scope.login = function(credentials) {
				$scope.isProcessing = true;

				Auth.login($scope.credentials).then(function(r) {
					$rootScope.$broadcast(AUTH_EVENTS.loginSuccess);
					$scope.setCurrentUser(r.data.owner);
					$localStorage.owner = {Id: r.data.owner.ownerId};
					$scope.isReady = true;
					$scope.isProcessing = false;
					UIMessage.success(r.message);	
					//$localStorage.user = {ownerId : r.data.owner.ownerId};
					$location.path('/users/'+r.data.owner.ownerId).replace();

				}, function(res) {
					$rootScope.$broadcast(AUTH_EVENTS.loginFailed);
					$scope.isProcessing = false;
					UIMessage.error(res.data.message);
				});

			};
		} ]);

appControllers.controller('SignupCtrl', [ '$scope', '$rootScope', '$location', 'AUTH_EVENTS',
		'Auth', 'UIMessage', function($scope, $rootScope, $location, AUTH_EVENTS, Auth, UIMessage) {
			$scope.signupdata = {
				name: 'John',
  				password: '123',
  				emailId: 'User1@gmail.com',
  				address: 'KBN',
  				contact: '9087654345'
			};

			$scope.isProcessing = false;
			$scope.isReady = false;

			$scope.isDisabled = function() {
				return $scope.isProcessing || $scope.isReady;
			};

			$scope.signup = function(signupdata) {
				$scope.isProcessing = true;

				Auth.signup($scope.signupdata).then(function(res) {
					$rootScope.$broadcast(AUTH_EVENTS.loginSuccess);
					$scope.setCurrentUser(res.data.user);

					$scope.isReady = true;
					$scope.isProcessing = false;

					UIMessage.success(res.message);
					$location.path('/login').replace();
				}, function(res) {
					$rootScope.$broadcast(AUTH_EVENTS.loginFailed);
					$scope.isProcessing = false;
					UIMessage.error(res.data.message)
				});

			};
		} ]);

appControllers.controller('IndexCtrl', [ '$scope', '$rootScope', function($scope, $rootScope) {
	$scope.hello = 'hi';
} ]);
