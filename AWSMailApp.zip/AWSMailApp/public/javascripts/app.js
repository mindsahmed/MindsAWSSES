'use strict';

/* App Module */

var theApp = angular.module('theApp', [ 'ngRoute', 'appControllers', 'ngMessages', 'ngStorage', 'appDirectives',
		'appServices', 'appConstants','angularjs-dropdown-multiselect' ]);

theApp.config([ '$routeProvider', 'USER_ROLES', function($routeProvider, USER_ROLES) {
	$routeProvider.when('/index', {
		templateUrl: '/assets/partial-html-app/index.html',
		controller: 'IndexCtrl',
		data: {
			authorizedRoles: [ USER_ROLES.any ]
		}
	}).when('/messages', {
		templateUrl: '/assets/partial-html-app/user/messages.html',
		controller: 'MessageListCtrl',
		data: {
			authorizedRoles: [ USER_ROLES.user ]
		}
	}).when('/users/:id', {
		templateUrl: '/assets/partial-html-app/admin/users.html',
		controller: 'UserListCtrl'
		/*data: {
			authorizedRoles: [ USER_ROLES.admin ]
		}*/
	}).when('/login', {
		templateUrl: '/assets/partial-html-app/login.html',
		controller: 'LoginCtrl',
		data: {
			authorizedRoles: [ USER_ROLES.any ]
		}
	}).when('/signup', {
		templateUrl: '/assets/partial-html-app/signup.html',
		controller: 'SignupCtrl',
		data: {
			authorizedRoles: [ USER_ROLES.any ]
		}
	}).otherwise({
		redirectTo: '/index'
	});
} ]);


