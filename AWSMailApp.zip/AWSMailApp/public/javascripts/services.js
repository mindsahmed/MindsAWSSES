'use strict';

/* Services */

var appServices = angular.module('appServices', [ 'ngResource' ]);

appServices.service('UIMessage', function() {
	toastr.options.closeButton = true;

	this.success = function(message) {
		toastr.success(message);
		console.log("success message from service "+ message);
	};

	this.error = function(message) {
		toastr.error(message);
	};
	
	this.message = function(message, status) {
		if(status.success) {
			this.success(message)
		} else {
			this.error(message)
		}
	}

	return this;
});

appServices.factory('Message', [ '$resource', function($resource) {
	return $resource('/auth/allMessageByOwnerId/:ownerId', {
		messageId: '@id'
	}, {
		query: {
			method: 'GET',
			params: {
				ownerId : null
			},
			isArray: true
		},
		create: {
			method: 'POST',
			params: {
				messageId: 'create'
			}
		},
		markRead: {
			method: 'POST',
			url: '/message/:messageId/mark-read'
		}
	})
} ]);

appServices.factory('User', [ '$resource', function($resource) {
	
	return $resource('/auth/getAllClientsByOwnerId/:ownerId', {
		userId: '@id'
	}, {
		query: {
			method: 'GET',
			params : {ownerId : null},
			isArray: true
		}
	})

} ]);

appServices.factory('Auth', [ '$http', 'Session', 'USER_ROLES',
		function($http, Session, USER_ROLES) {
			var authService = {};

			authService.signup = function(signupdata) {
				return $http.post('/auth/signUp ', signupdata).then(function(res) {
					var d = res.data;
					//Session.create(d.data.session.token, d.data.user.id, d.data.user.roles);
					return d;
				});
			};

			authService.login = function(credentials) {
				return $http.post(' /auth/signIn', credentials).then(function(res) {
					var d = res.data
				//	Session.create( d.data.owner.ownerId);
					return d;
				});
			};
			authService.create = function(user) {
				return $http.post(' /auth/createClient', user).then(function(res) {
					var d = res.data
				//	Session.create(d.data.session.token, d.data.user.id, d.data.user.roles);
					return d;
				});
			};
			 
			authService.createMessage = function(message) {
				return $http.post(' /auth/createMessage', message).then(function(res) {
					var d = res.data
				//	Session.create(d.data.session.token, d.data.user.id, d.data.user.roles);
					return d;
				});
			};
			authService.getAllClients = function(ownerId) {
				return $http.get('/auth/getAllClientsByOwnerId/'+ownerId).then(function(res) {
					console.log("in service"+res.clinetId);
				});
			};


			authService.isAuthenticated = function() {
				return !!Session.userId;
			};

			authService.isAuthorized = function(authorizedRoles) {
				if (!angular.isArray(authorizedRoles)) {
					authorizedRoles = [ authorizedRoles ];
				}

				// checking authorized for roles 'any' and 'guest' before checking
				// authentication
				var isA = false;
				var anyguest = [ USER_ROLES.any, USER_ROLES.guest ];

				angular.forEach(Session.userRoles.filter(function(role) {
					return anyguest.indexOf(role) !== -1;
				}), function(role, i) {
					isA = isA || (authorizedRoles.indexOf(role) !== -1);
				});

				if (isA)
					return true;

				if (!authService.isAuthenticated()) {
					return false;
				}

				isA = false;
				angular.forEach(Session.userRoles, function(role, i) {
					isA = isA || (authorizedRoles.indexOf(role) !== -1);
				});

				return isA;
			};

			return authService;
		} ]);

appServices.service('Session', [ 'USER_ROLES', function(USER_ROLES) {
	this.create = function(token, userId, userRoles) {
		this.token = token;
		this.userId = userId;
		this.userRoles = userRoles;
		this.userRoles.unshift(USER_ROLES.any);
	};

	this.destroy = function() {
		this.token = null;
		this.userId = 0;
		this.userRoles = [ USER_ROLES.any, USER_ROLES.guest ];
	};

	this.destroy();

	return this;
} ])
