import scala.concurrent.duration._
import scala.concurrent.Await

import net.codingwell.scalaguice.ScalaModule
import net.codingwell.scalaguice.InjectorExtensions._
import com.google.inject.{Guice, Provides, Injector, AbstractModule}

import org.specs2.mutable._
import org.specs2.runner._
import org.junit.runner._
import play.api.test._
import play.api.test.Helpers._

import services.{MessageService, MessageServiceImpl}
import dtos.{MessageDTO, UserDTO}
import models.daos.{MessageDAO, UserDAO}

/**
 * Add your spec here.
 * You can mock out a whole application including requests, plugins etc.
 * For more information, consult the wiki.
 */
@RunWith(classOf[JUnitRunner])
class MessageServiceSpec extends PlaySpecification {
  //sequential

  trait MSScope extends org.specs2.specification.Scope {
    var usrs: List[UserDTO] = List[UserDTO](
        UserDTO(id = 1, username = "user1", passwordHash = "hash1", firstName = Some("Name1"), lastName = Some("Lastname1"), niceName = Some("Name1 Lastname1")),
        UserDTO(id = 2, username = "user2", passwordHash = "hash2", firstName = Some("Name2"), lastName = Some("Lastname2"), niceName = Some("Name2 Lastname2")),
        UserDTO(id = 3, username = "user3", passwordHash = "hash3", firstName = Some("Name3"), lastName = Some("Lastname3"), niceName = Some("Name3 Lastname3")))

    var msgs: List[MessageDTO] = List[MessageDTO](
        MessageDTO(id = 1, fromId = 1, toId = 2, text = "hello12", isRead = false, fromNiceName = usrs(0).niceName, toNiceName = usrs(1).niceName),
        MessageDTO(id = 2, fromId = 2, toId = 1, text = "hello21", isRead = false, fromNiceName = usrs(1).niceName, toNiceName = usrs(0).niceName),
        MessageDTO(id = 3, fromId = 3, toId = 2, text = "hello32", isRead = true, fromNiceName = usrs(2).niceName, toNiceName = usrs(1).niceName))

    var existingId: Int = 1
    var notExistingId: Int = 10000
    var injector: Injector = Guice.createInjector(new MSSModule)
    val MS: MessageService = injector.instance[MessageService]

    class MSSModule extends AbstractModule with ScalaModule {
      val messageDAOMock = new MessageDAO {
        override def byId(id: Long) = msgs.find(_.id == id)
        override def byUserId(userId: Long) = msgs.filter(m => m.fromId == userId || m.toId == userId)
        override def delete(msgId: Long) = {
          val omsgs = msgs
          msgs = msgs.filter(_.id != msgId)

          omsgs.length != msgs.length
        }
        override def update(message: MessageDTO) = {
          val i = msgs.indexOf(message)
          if (i > -1)
            msgs = msgs.updated(i, message)
        }
        override def create(fromId: Long, toId: Long, text: String) = {
          val newI = msgs.length + 1
          val fromU = usrs.find(_.id == fromId.toInt).get
          val toU = usrs.find(_.id == toId.toInt).get
          val m = MessageDTO(newI, fromId, toId, text, false, fromU.niceName, toU.niceName)
          msgs = m :: msgs
          m
        }
      }

      val userDAOMock = new UserDAO {
        override def byId(id: Long) = usrs.find(_.id == id)
        override def delete(uId: Long) = {
          val ousrs = usrs
          usrs = usrs.filter(_.id != uId)

          ousrs.length != usrs.length
        }
        override def update(u: UserDTO) = {
          val i = usrs.indexOf(u)
          if (i > -1)
            usrs = usrs.updated(i, u)
        }
        override def insert(user: UserDTO) = {
          val newI = usrs.length
          val u = user.copy(id = newI)
          //val u = UserDTO(newI, s"username$newI", passwordHash = s"hash$newId", Some(s"Name$newI"), Some(s"Lastname$newI"), fromU.niceName, toU.niceName)
          usrs = u :: usrs
          u
        }
      }

      override def configure() = {
        bind[MessageService].to[MessageServiceImpl]
      }

      @Provides
      def provideMessageDAO(): MessageDAO = messageDAOMock
      @Provides
      def provideUserDAO(): UserDAO = userDAOMock
    }
  }

  "MessageServiceImpl delete" should {
    "return false when deleting not existing message" in new MSScope {
      MS.delete(notExistingId) must be_==(false).await
    }

    "return true when deleting existing messsage" in new MSScope {
      MS.delete(existingId) must be_==(true).await
    }
  }
  
  "MessageServiceImpl sendMessage" should {
    "return new message with new id when both users exist" in new MSScope {
      val existingIdes = msgs.map(_.id)
      val fromId = 1
      val toId = 2
      val text = "Hello"
      val msg = await(MS.sendMessage(fromId, toId, text))

      existingIdes must not contain(msg.id)
      msg.fromId must be_==(fromId)
      msg.toId must be_==(toId)
      msg.text must be_==(text)
    }
  }
}
